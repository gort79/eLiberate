<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <title>Soonr is coming soon...</title>
        <meta name="description" content="Description of your Site">
        <meta name="author" content="CREATEBRILLIANCE - Media &amp; Consulting">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="css/bootstrap.min.css">

        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
        <link rel="stylesheet" href="owl-carousel/owl.theme.css">
        <link rel="stylesheet" href="css/animate.css">
        <link rel="stylesheet" href="css/main.css">
        
        <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>

        <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
        
        
        
    </head>
        <body>
    	<div id="video-wrapper">
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
        
     <div id="preloader">
		<div id="spinner_container">
			<img src="img/spinner.gif" alt=""/>
		</div>
	</div>
  	<!-- Side Menu -->
  	
  	
  	<nav class="bt-menu-close" id="menu-toggle">
				<a class="bt-menu-trigger" href="#"><span>Menu</span></a>
	</nav>

	<div id="sidebar-wrapper">
		<ul class="sidebar-nav">
			
			<li class="sidebar-brand">
				Navigation
			</li>
			<li class="show-modal nav-newsletter" data-modal="newsletter">
				<a href="#"><i class="fa fa-envelope-o"></i> Newsletter</a>
			</li>
			<li class="show-modal nav-about" data-modal="about">
				<a href="#"><i class="fa fa-flask"></i> About</a>
			</li>
			<li class="show-modal nav-contact" data-modal="contact">
				<a href="#"><i class="fa fa-users"></i> Contact</a>
			</li>

		</ul>
	</div>
			

	<section id="modal">
		<div class="bt-modal-close"><span></span></div>
		<article id="modal-newsletter">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2><i class="fa fa-envelope-o"></i> Subscribe to our newsletter</h2>
					</div>
					<div class="col-md-6">
						<p>
							Be the first one to know when we go live. Get <b>awesome</b> news about our company and always stay up to date with us.					
						</p>					
					</div>
					<div class="col-md-6">
						<form id="newsletter-form" class="form-inline" role="form">
							<div class="form-group">
								<label class="sr-only" for="emailInputNewsletter">Email address</label>
								<input type="email" name="emailInputNewsletter" class="form-control" id="emailInputNewsletter" placeholder="Enter your email">
								<button id="newsletter-submit-mailchimp" type="submit" class="btn btn-submit" name="submit">
									<i class="fa fa-check"></i> SUBMIT
								</button>
							</div>
							<small>Don't worry we will not use your email for spam</small>
							<div id="newsletter-form-response"></div>
						</form>
					</div>
				</div>
			</div>
		</article>

		<article id="modal-about">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2><i class="fa fa-flask"></i> What we do</h2>
						<p>
							We create awesome stuff. Check out what we can do for you!
						</p>
						<div id="owl-carousel" class="owl-carousel">
							<div class="owl-container text-center">
								<div class="img-container"><img src="img/icons/1.png" class="img-responsive" alt="" /></div><h2>We Work</h2>
								<p>We work 24/7 a day to keep you satisfied.</p>
							</div>
							<div class="owl-container text-center">
								<div class="img-container"><img src="img/icons/2.png" class="img-responsive" alt="" /></div><h2>We Love</h2>
								<p>We love our products.</p>
							</div>
							<div class="owl-container text-center">
								<div class="img-container"><img src="img/icons/3.png" class="img-responsive" alt="" /></div><h2>We're Mobile</h2>
								<p>Connect with us from any device.</p>
							</div>
							<div class="owl-container text-center">
								<div class="img-container"><img src="img/icons/4.png" class="img-responsive" alt="" /></div><h2>We Repair</h2>
								<p>Something is broken? We can fix it.</p>
							</div>
							<div class="owl-container text-center">
								<div class="img-container"><img src="img/icons/5.png" class="img-responsive" alt="" /></div><h2>We Conjure</h2>
								<p>We've got some magic hands.</p>
							</div>
							<div class="owl-container text-center">
								<div class="img-container"><img src="img/icons/6.png" class="img-responsive" alt="" /></div><h2>We Drink</h2>
								<p>30 cups of coffee a day.</p>
							</div>
							<div class="owl-container text-center">
								<div class="img-container"><img src="img/icons/7.png" class="img-responsive" alt="" /></div><h2>We find</h2>
								<p>We find what you are looking for.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</article>

		<article id="modal-contact">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2><i class="fa fa-users"></i> Contact</h2>
					</div>
					<div class="col-md-6">
						<h3>Our Address</h3>
						<address>
							<strong>Soonr</strong>
							<br>
							795 Folsom Ave, Suite 600
							<br>
							San Francisco, CA 94107
							<br>
							<abbr title="Phone">P:</abbr> (123) 456-7890
							<br>
							<a href="mailto:#">mail@soonr.com</a>
						</address>
						<p>
							You can get in touch with us 24 hours, 7 days a week.
						</p>
					</div>
					<div class="col-md-6">
							<h3>Where we are located</h3>
							<figure  class="gmap">
									<img src="http://maps.google.com/maps/api/staticmap?center=New%20York%20City&zoom=15&size=640x200&maptype=roadmap&sensor=false&markers=icon:http://themes.createbrilliance.com/Soonr/theme/img/map-marker.png|New%20York%20City" alt=" "/>
							</figure>

					</div>
				</div>
			</div>
		</article>
		
	</section>

	<section id="head">
			<div class="container">
				<div class="row animated" data-animation-delay="500" data-animation="bounceInDown">
					<div class="col-md-12 text-center">
						<h1>Under
						<br/>
						Construction</h1>
						<hr>
						<h3> 
							Hey we are <b>Soonr</b>. We are currently working on our new site. Stay tuned
							<br/>
							You can subscribe to our newsletter in order to get notified when we launch.
							<br/>
							Go check us out on <b>facebook</b> and <b>twitter</b>, too. <br/><br/>
										
							Subscribe to our <a href="#" class="show-modal btn btn-default" data-modal="newsletter"><i class="fa fa-envelope-o"></i> Newsletter</a>
						</h3>
					</div>
				</div>
				
				<div class="row">
					<div class="divider">
						<i class="fa fa-clock-o"></i> <h2>We will be back in</h2>
					</div>
				</div>
				
				<div class="row  countdown">				
					<div class="col-md-3 animated" data-animation-delay="0" data-animation="fadeInUp">
						<div id="days">00</div><div id="days-text">Days</div>
					</div>
					<div class="col-md-3 animated" data-animation-delay="200" data-animation="fadeInUp">
						<div id="hours">00</div><div id="hours-text">Hours</div>
					</div>
					<div class="col-md-3 animated" data-animation-delay="400" data-animation="fadeInUp">
						<div id="minutes">00</div><div id="minutes-text">Mins</div>
					</div>
					<div class="col-md-3 animated" data-animation-delay="600" data-animation="fadeInUp">
						<div id="seconds">00</div><div id="seconds-text">Secs</div>
					</div>
				</div>
			</div><!--container-->
	</section>

    <footer>    	
     		<div class="container">
				<div class="row text-center animated" data-animation-delay="200" data-animation="bounceIn">
					<div class="col-md-12">
						<div class="social-icons">
							<a href="#" target="_blank" class="facebook"><i class="fa fa-facebook"></i></a>
							<a href="#" target="_blank" class="flickr"><i class="fa fa-flickr"></i> </a>
							<a href="#" target="_blank" class="linkedin"><i class="fa fa-linkedin"></i> </a>
							<a href="#" target="_blank" class="pinterest"><i class="fa fa-pinterest"></i> </a>
							<a href="#" target="_blank" class="dribbble"><i class="fa fa-dribbble"></i> </a>
							<a href="#" target="_blank" class="dropbox"><i class="fa fa-dropbox"></i> </a>
							<a href="#" target="_blank" class="instagram"><i class="fa fa-instagram"></i> </a>
						</div>
					</div>
					        <p class="copy">&copy; Company 2014</p>
				</div>
			</div>
    </footer>

      
      <div class="bokeh"></div>
      				
		<div id="slides">
			<div class="slides-container">
								
			</div>
		</div>
      
          
    </div><!--video-wrapper-->
      
   		<script  type="text/javascript" src="js/vendor/jquery-1.10.1.min.js"></script>
		<script  type="text/javascript" src="js/vendor/bootstrap.min.js"></script>
		<script  type="text/javascript" src="js/plugins.js"></script>
		<script  type="text/javascript" src="owl-carousel/owl.carousel.min.js"></script>
		<script  type="text/javascript" src="js/main.js"></script>
		
		<script type="text/javascript" src="mailchimp/js/mailing-list.js"></script>
        
        <script  type="text/javascript">
        	$(document).ready(function(){			
       			/*
       			 * STATIC BACKGROUND
       			 */
       			$("body").css({ 
       				"background":"#3498db"
       			});
       			
        	});
        	
        	$(window).load(function(){
        	
        	});
        </script>
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-37176788-3', 'createbrilliance.com');
  ga('send', 'pageview');

</script>    
    </body>
</html>
